import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.LinkedList;
import java.util.Queue;

//BMIcalculator5 class that implements the Patient interface
public class BMIcalculator6 implements Patient2 {
	
	@Override
	public double calculateBMI(double weight, double height) {
		
		//Calculating the BMI with the formula
		return (weight * 703) / (height * height);

	}

public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		try(BufferedWriter bWriter = new BufferedWriter(new FileWriter("C:/Users/17865/Documents/Rasmussen/Java Programming/Module 04/BMICalculator1.csv"))) {
			
			// creates a list that contains queue of strings
			List<Queue<String>> outputTable = new ArrayList<>();
			
			//Continuous User data Entry saving inputs to Queue until the user exits with "q"
			while (true) {
				Queue <String> outputRow = new LinkedList<>();
				
				System.out.println("------Insurance BMI calculator------");
				
				System.out.println("Please enter Patient's name:");
				outputRow.add(input.nextLine());
		
				System.out.println("Plase enter Patient's birthday:");
				outputRow.add(input.nextLine());
		
				System.out.println("Please enter Patient's weight (pounds):");
				String weight = input.nextLine();
				outputRow.add(weight);
		
				System.out.println("Please enter Patient's height (inches):");
				String height = input.nextLine();
				outputRow.add(height);
				
				//implementing the method to calculate BMI
				BMIcalculator6 patient = new BMIcalculator6();
				double total = patient.calculateBMI(Double.parseDouble(weight), Double.parseDouble(height));
				
				//Displaying results and setting parameters
				String message = "";
				String message2 = "";
				if (total < 18.5) {
				  message = "Underweight";
				  message2 = "Low";
				} else if(total >= 18.5 && total <= 24.9 ) {
				  message = "Normal weigth";
				  message2 = "Low";
				} else if(total >= 25 && total <= 29.9) {
					  message = "Over weight";
					  message2 = "High";
				} else if(total > 29.9) {
				  message = "Obesity";
				  message2 = "Highest";
				}
				outputRow.add(message);
				outputRow.add(message2);
				
				
				outputTable.add(outputRow);
				
				System.out.println("Press any key to continue or 'q' to quit.");
				if (input.nextLine().equals("q")) {
					break;
				}
			}
			
			//creating the headers for the file
			StringBuilder sb = new StringBuilder();
			sb.append("Name");
			sb.append(",");
			sb.append("Birthday");
			sb.append(",");
			sb.append("Weight");
			sb.append(",");
			sb.append("Height");
			sb.append(",");
			sb.append("BMI_Category");
			sb.append(",");
			sb.append("Payment_Category");
			sb.append(System.lineSeparator());
			
			// Add the headers to the file
			bWriter.write(sb.toString());
			
			// Add each input value
			while (!outputTable.isEmpty()) {
				
				// Clear out the StringBuilder
				sb.delete(0, sb.length());
				
				Queue<String> outputRow = outputTable.remove(0);
				
				// Getting all the values
				sb.append(outputRow.remove());// Name
				sb.append(",");
				sb.append(outputRow.remove());// Birthday
				sb.append(",");
				sb.append(outputRow.remove());// Weight
				sb.append(",");
				sb.append(outputRow.remove());// Height
				sb.append(",");
				sb.append(outputRow.remove());// BMI Category
				sb.append(",");
				sb.append(outputRow.remove());// Payment Category
				sb.append(System.lineSeparator());

				// Writes to the file
				bWriter.write(sb.toString());
			}
		}catch (Exception e) {
			//catching any exception that might occur during user input
			System.out.println("Exception: " + e.toString() );
		}
		finally {
			// closing the scanner 
			input.close();
			System.out.println("The program is exiting...");
		}
	}
}
