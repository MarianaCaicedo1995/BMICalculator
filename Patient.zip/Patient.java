
public interface Patient {

	public double paymentCategoryAndBMI(double weight, double height);
		
}
