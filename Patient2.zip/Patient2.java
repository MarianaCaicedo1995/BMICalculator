
public interface Patient2 {

	public double calculateBMI(double weight, double height);
		
}

